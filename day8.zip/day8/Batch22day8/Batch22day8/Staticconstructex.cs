﻿using System;
namespace Batch22day8
{
    class Mydata
    {
        public int id, marks;
        public static int grace;
        public Mydata()
        {
            id = 0;
        }
        public void getdata()
        {
            Console.WriteLine("Enter id and marks");
            id = int.Parse(Console.ReadLine());
            marks = int.Parse(Console.ReadLine());
        }
        public Mydata(int x,int y)
        {
            id = x;
            marks = y;
        }
        static Mydata()
        {
            grace = 5;
        }
        public void display()
        {
            Console.WriteLine("ID              =" + id);
            marks += grace;
            Console.WriteLine("MARKS            =" + marks);
        }
    }
    class Staticconstructex
    {
        static void Main(string[] args)
        {
            Mydata ob = new Mydata();
            ob.getdata();
            Console.WriteLine("Grace marks = " + Mydata.grace);
            ob.display();
        }
    }
}
