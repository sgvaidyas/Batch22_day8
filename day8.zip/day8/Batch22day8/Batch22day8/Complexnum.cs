﻿using System;

namespace Batch22day8
{
    class Complexnum
    {
        public int real, imag;
        public Complexnum()
        {
            Console.WriteLine("Enter real and imaginary part");
            real = int.Parse(Console.ReadLine());
            imag = int.Parse(Console.ReadLine());
        }
        public void printme()
        {
            Console.WriteLine("Complex num = " +real + "+"+imag+"i");
        }
        public static bool operator==(Complexnum ob1 , Complexnum ob2)
        {
            bool isequal=false;
            if (ob1.real == ob2.real && ob1.imag == ob2.imag)
                isequal = true;

            return isequal;
        }
        public static bool operator!=(Complexnum ob1, Complexnum ob2)
        {
            bool isnotequal = false;
            if (ob1.real != ob2.real || ob1.imag != ob2.imag)
                isnotequal = true;

            return isnotequal;
        }

        static void Main(string[] args)
        {
            Complexnum ob1 = new Complexnum();
            Complexnum ob2 = new Complexnum();
            ob1.printme();
            ob2.printme();

            if (ob1==ob2)
                Console.WriteLine("Both objects have same val");
            else
                Console.WriteLine("Both objects are not same");
        }
    }
}
