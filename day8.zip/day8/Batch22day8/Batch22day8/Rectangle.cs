﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class Rectangle
    {
        public int len, bred, area, peri;

        public Rectangle()
        {
            len = 6;
            bred = 2;
        }
        public Rectangle(int x)
        {
            len = x;
            bred = x;
        }
        public Rectangle(int x,int y)
        {
            len = x;
            bred = y;
        }
        public void calculate()
        {
            area = len * bred;
            peri = 2 * (len + bred);
        }
        public void display()
        {
            Console.WriteLine("LENGTH     = " + len);
            Console.WriteLine("BREADTH    = " + bred);
            Console.WriteLine("AREA       = " + area);
            Console.WriteLine("PERIMETER  = " + peri);

        }

        ~Rectangle()
        {
            Console.WriteLine("\nI am destructing len = "+len + " bred = " +bred );
        }

    }
}
