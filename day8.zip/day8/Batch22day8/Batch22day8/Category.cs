﻿using System;

namespace Batch22day8
{
    class Category
    {
        public int cid;
        public string cname;

        public void getcat()
        {
            Console.Write("Enter CID    =");
            cid = int.Parse(Console.ReadLine());
            Console.Write("Enter CNAME  =");
            cname = Console.ReadLine();
        }
        public void dispcat()
        {
            Console.WriteLine("PID           = " + cid);
            Console.WriteLine("CATNAME       = " + cname);

        }
    }
}