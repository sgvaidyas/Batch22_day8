﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class Thisexample
    {
        public static int totalfees = 0;

        public int id, fees;
        public string name;
             

        public Thisexample(int id,int fees,string name)
        {
            this.id = id;
            this.fees = fees;
            this.name = name;
            totalfees += fees;
        }
        public void display()
        {
            Console.WriteLine("ID         = " + id);
            Console.WriteLine("NAME       = " + name);
            Console.WriteLine("FEES       = " + fees);

        }
        
    }
}
