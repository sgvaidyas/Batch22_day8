﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class thisimp
    {
        static void Main(string[] args)
        {
            Thisexample ob = new Thisexample(11, 2000, "Asha");
            Thisexample ob1 = new Thisexample(12, 3000, "Sushma");
            Thisexample ob2 = new Thisexample(15, 5000, "Adil");

            ob.display();
            ob1.display();
            ob2.display();
            Console.WriteLine("Total fees = " + Thisexample.totalfees);
        }
    }
}
