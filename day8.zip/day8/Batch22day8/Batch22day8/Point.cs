﻿using System;

namespace Batch22day8
{
    class Point
    {
        public int x, y;
        public Point()
        {
            x = 0;
            y = 0;
        }
        public Point(int x,int y)
        {
            this.x = x;
            this.y = y;
        }
        public void display()
        {
            Console.WriteLine("X = " + x);
            Console.WriteLine("Y = " + y);

        }
        public Point add(Point b )
        {
            Point res = new Point();
            res.x = this.x + b.x  ;
            res.y = this.y + b.y;
            return res;

        }
        public static Point operator-(Point a,Point b)
        {
            Point res = new Point();
            res.x = a.x - b.x;
            res.y = a.y - b.y;
            return res;
        }
        public static Point operator -(Point a)
        {
            Point res = new Point();
            res.x = - a.x;
            res.y = - a.y;
            return res;
        }
        static void Main(string[] args)
        {
            Point a = new Point(2, 3);
            Point b = new Point(6, 4);
            Point c = a.add(b);
            c.display();

            Point d = a - b;
            d.display();

            Point ob = -d;
            ob.display();
        }
    }
}
