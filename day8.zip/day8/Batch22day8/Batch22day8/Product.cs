﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class Product
    {
        public int Pid, cid;
        public string pname;
        public float price;

        public void getprod()
        {
            Console.Write("Enter PID    =");
            Pid = int.Parse(Console.ReadLine());
            Console.Write("Enter CID    =");
            cid = int.Parse(Console.ReadLine());
            Console.Write("Enter PNAME  =");
            pname = Console.ReadLine();
            Console.Write("Enter PRICE  =");
            price = float.Parse(Console.ReadLine());

        }
        public void dispprod()
        {
            Console.WriteLine("PID           = " +Pid);
            Console.WriteLine("PNAME         = " + pname);
            Console.WriteLine("CID           = " + cid);
            Console.WriteLine("PRICE         = " + price);
        }
    }
}
