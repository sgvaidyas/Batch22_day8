﻿using System;

namespace Batch22day8
{
    static class MyDemostatic
    {
        public static string category = "Students";
        public static void display()
        {
            Console.WriteLine("Category = "+category);
        }
        public static void myfun()
        {
            Console.WriteLine("MYFUN");
        }  
    }
    class Staticclasses
    {
        static void Main(string[] args)
        {
            MyDemostatic.display();
            MyDemostatic.category = "Employee";
            MyDemostatic.display();
            MyDemostatic.myfun();
        }
    }
}
