﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle ob1 = new Rectangle();
            ob1.calculate();
            ob1.display();

            Rectangle ob2 = new Rectangle(3);
            ob2.calculate();
            ob2.display();

            Rectangle ob3 = new Rectangle(2, 6);
            ob3.calculate();
            ob3.display();

        }
    }
}
