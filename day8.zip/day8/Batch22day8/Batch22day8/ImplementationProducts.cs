﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class ImplementationProducts
    {
        static void Main(string[] args)
        {
            Orders ob = new Orders();

            ob.getOrders();
            ob.display();
        }
    }
}
