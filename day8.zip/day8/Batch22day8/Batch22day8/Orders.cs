﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day8
{
    class Orders
    {
        public int orderid, qty, custid;
        public Product p;
        public Category c;

        public void getOrders()
        {
            p = new Product();
            c = new Category();
            p.getprod();
            c.getcat();
            Console.Write("Enter orderid    =");
            orderid = int.Parse(Console.ReadLine());
            Console.Write("Enter quantity   =");
            qty = int.Parse(Console.ReadLine());
            Console.Write("Enter custid    =");
            custid = int.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("ORDERID       = " + orderid);
            Console.WriteLine("CUSTID        = " + custid);
            Console.WriteLine("QTY           = " + qty);
            p.dispprod();
            Console.WriteLine("TOTALPRICE    = " + (qty*p.price ));

            c.dispcat();
        }
    }
}
